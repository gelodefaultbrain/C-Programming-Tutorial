#include<stdio.h>

int main()
{
 int array[] = {4,2,1,0};

 int key;
 bool found = false;

 printf("Enter the number you want to search\n");
 scanf("%i",&key);

 int i;
 
 for(i=0; i<4; i++)
 {

   if(array[i] == key)
   {
     found= true;
     printf("Found at index[%i]",i);
   }
 

 }

 if(!found)
 {
   printf("Sorry hindi namin nahanap!\n");
 }




}