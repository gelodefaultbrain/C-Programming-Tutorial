#include<stdio.h>

union Data
{
  int x;
  char let;
};

int main()
{

 union Data example;

 example.x = 100;
 example.let = 'M';
 printf("union x is equal to %i",example.x); 


/*

With a union, you're only supposed to use one of the elements, because they're all stored at the same spot.
This makes it useful when you want to store something that could be one of several types. 
A struct, on the other hand, has a separate memory location for each of its elements and they all can be used at once.


Source: https://stackoverflow.com/questions/346536/difference-between-a-structure-and-a-union


*/
 

}