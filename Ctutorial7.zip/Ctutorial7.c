#include<stdio.h>

int main()
{

int number = 10;

/*
Take note you can try other comparison symbols
> greater than
< less than
== equal (others say it equal equal)
!= not equal
*/


if (number > 100)
{
 printf("Yes it is greater than 100");
}else if(number == 10)
{
 printf("Yes it is equal to 10");
}else if(number < 2)
{
 printf("Yes it is less than 2");
}else
{
 printf("Hello World, This will be printed out if walang na met sa mga previous conditions");
}



}