#include<stdio.h>

int main()
{

//Take note that pwede to kahit sa ibang type of loops

int i;

//continue;
for(i=0; i < 15; i++)
{

  if(i==8)
  {
    continue;
  }else
  {
   printf("%i\n",i);
  }

}



//break;
for(i=0; i < 10; i++)
{

  if(i==4)
  {
     printf("STOP!!\n");
     break;
  }else
  {
   printf("%i\n",i);
  }

}





}