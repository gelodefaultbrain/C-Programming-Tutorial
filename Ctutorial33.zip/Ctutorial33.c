#include<stdio.h>

int main()
{

 int x = 6;
 int y = x<<2; 

/*

<< - LEFT

>> - RIGHT

*/

 printf("%i",y); 

}