#include<stdio.h>

int main()
{

/*
int counter;

for(counter=0; counter <= 5; counter++)
{
printf("%i\n",counter);
}

*/


char letter = 'A';
int x;
printf("Enter how many times you want to Display the char\n");
scanf("%i",&x);

int counter;

for(counter =0; counter < x; counter++)
{
printf("%c\n",letter);
}



//Infinite for loop

/*

for(;;)
{
printf(" WALANG FOREVER :( ");
}

*/


}