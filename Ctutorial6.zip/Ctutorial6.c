#include<stdio.h>

int main()
{

/*

int age;
int girl_age;

printf("Please enter your current Age\n");

scanf("%i",&age);

girl_age = age/2+7;

printf("Recommended age to date a girl is: %i\n",girl_age);

*/ 

float faren;
printf("Enter the value of F:\n");
scanf("%f",&faren);

float cel = (faren - 32) * 5/9;

printf("C = %.2f\n",cel);

return 0;

//for fahrenheit

/*

float Faren = (cel *9/5)+32;

printf("Value of fahrenheit is %f\n",Faren);

*/

}