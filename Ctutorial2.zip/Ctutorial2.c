#include<stdio.h>

int main()
{
 printf("Hello World");
 printf("Mahal kita, I love you :( ");

 //single line comment
 
 /*
  multiple lines comment
  another line
  and another one!
  isa nanaman!
  last na to
 */

}