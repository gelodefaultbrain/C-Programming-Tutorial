// own made deletion for n
#include<stdio.h>
int main()
{
	int numbers[100];
	int x;
	int a;
	printf("Enter how many numbers you want\n");
	scanf("%i",&x);
	printf("Enter those numbers\n");
	for(a=0; a < x; a++)
	{
		scanf("%i",&numbers[a]);
	}
	int loc;
	printf("Enter the location of your numbers that you want to delete\n");
	scanf("%i",&loc);
	int n;
	for(n=loc-1; n <= x -1; n++)
	{
		numbers[n] = numbers[n+1];
	}
	int t;
	printf("Your new set of arrays are\n");
	for(t=0; t < x-1; t++)
	{
		printf("numbers[%i] = %i\n",t,numbers[t]);
	}
}
