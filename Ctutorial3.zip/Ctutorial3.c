#include<stdio.h>

int main()
{

int age = 19;
char letter = 'e';
bool choice = false;
double number = 3.14;
float fl = 2.17123;
long l = 123456789;

printf("My age is %i \n",age);
printf("Value of letter in %c\n",letter);
printf(choice?"true":"false");
printf("\n");
printf("The value of number is %.2f\n",number);
printf("The value of fl is %.3f\n",fl);
printf("The value of l is %ld",l);

//printf more than 1 variables in a single printf();
int x = 2;
char ch = 'Q';

printf("x = %i ,ch = %c ",x,ch);

}