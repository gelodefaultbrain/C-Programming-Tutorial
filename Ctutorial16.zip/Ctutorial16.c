#include<stdio.h>

void SayHello(); //Function Declaration
void printNumbers(int x, int y , int z);

/*
you don't have to declare the function if you create the function 
before the main method
*/
int addNumbers(){
  int a = 1;
  int b = 2;
  int c = a + b;
  
  return c; //returns the value of c, so it would mean that our addNumbers(); function will have the value of c
}

int main()
{
  //SayHello();

  int sum = addNumbers();

  printf("%i",sum);


  int num = 300;
  printNumbers(num,10,100);


}

void SayHello(){
 printf("Hello");
}



void printNumbers(int x, int y , int z){
    printf("%i\n",x);
    printf("%i\n",y);
    printf("%i\n",z);
}
