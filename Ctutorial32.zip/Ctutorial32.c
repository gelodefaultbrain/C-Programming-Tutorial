#include<stdio.h>
#include<stdlib.h>

struct Data
{
  int x;
  struct node *next;
};

int main()
{

 struct Data *head = NULL;
 struct Data *first = NULL;
 struct Data *second = NULL;

 head = (struct Data*) malloc(sizeof(Data));
 first = (struct Data*) malloc(sizeof(Data));
 second = (struct Data*) malloc(sizeof(Data));
 

 head->x = 100;
 head->next = first;

 first->x = 200;
 first->next = second;

 printf("%i",first->x);

 second->x = 300;
 second->next = NULL;

}