#include<stdio.h>

void printNumbers(int *ptr){
  int i;

  for(i=0; i < 5; i++)
  {
    printf("Number %i\n",*(ptr+i));
  }  

}

int main()
{
 
 int array[] = {4,3,7,2,1};

 printNumbers(array); 

}