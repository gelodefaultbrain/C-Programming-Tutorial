#include<stdio.h>

int main()
{

//<= >=
//nested if else
//! NOT OPERATOR

/*

int a =10;
int b = 2;

if(!(a>=b))
{
printf("Yes it is greater than or equal to b");
}else
{
printf("No");
}

*/

int a = 1;
int b = 5;

//nested if else

if(a > 5)
{

 if(b < 100)
 {
    printf("b is less than 100");
 }else
 {
    printf("No 2nd part");
 }

}else
{
printf("NO 1ST PART");
}

}