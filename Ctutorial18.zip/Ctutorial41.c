#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
// FUNCTIONS STATION 
// Choice 'a' functions here
struct NODE 
       {  
	     int number;
	     struct NODE *next;
       };
// FUNCTION DECLARATIONS //       
void display_list(struct NODE *llist);
void append_node(struct NODE *llist , int num);
void delete_node(struct NODE *llist , int num);
int search_value(struct NODE *llist , int num);

int done();
int lqueint();
int lquestr();
int intall();
int strall();
void stringfunc();
void intproc();
void printarr();
void choiceko();
void stacks();
void linklist();
void wordproc();
void intque();
void strque();
void winsert();
void wdelete();
void wsearch();
void intsert();
void intdel();
void intsrch();
void cirque();
void queue();
void linque();
int intstck();
int strstck();
void wbubblesort();
void intbubblesort();
//                    //

 int main()
{
	// Variable Declarations station
     char choice;
     //
    /*               */ 
        printf("\t===============\t\n");
        printf("\tMENU\t\n");
        printf("a. String Processing\n");
        printf("b. Linear Data Structure\n");
        printf("c. Non Linear Data Structure\n");
        printf("d. Quit =)\n");
        printf("\nPlease enter your choice\n");
        printf("Your choice is :");
        scanf("%c",&choice);
        system("cls");
        printf("\n");
        
   switch(choice)
     {
        case 'a':
        choiceko();
        break;
        case 'b':
        printarr();
        break;
        case 'c':
        printf("Not yet discussed , I think...\n");
        main();
        break;
        case 'd':
        printf("\t    THANK YOU! =) =)");
        printf("\n");
        done();
        printf("\tHAVE A NICE DAY! =) =)\n");
        return 0;
        break;
        default:
        system("cls");
        main();
        break;
       }  
}
int done()
{
	int i, space, rows, k=0;
	rows = 10;
    for(i=1; i<=rows; ++i, k=0)
    {
        for(space=1; space<=rows-i; ++space)
        {
            printf("  ");
        }

        while(k != 2*i-1)
        {
            printf("* ");
            ++k;
        }

        printf("\n");
    }
    
    return 0;

}
void choiceko()
{
         int choice1;
         printf("\tSTRING PROCESSING OPERATIONS\n");
         printf("1. String Functions\n");
         printf("2. Integer Processing -- This is just an additional page =)\n");
         printf("3. Word Processing\n");
         printf("4. Exit:\n");
         printf("Enter the number of your choice\n");
         scanf("%i",&choice1);  
         system("cls");
 
         switch(choice1)
         {
          case 1:
          stringfunc();
          break;
          case 2:
          intproc();
          break;
          case 3:
          wordproc();
          break;
		  case 4:
		  default:
		  system("cls");
		  main();
		  break;  
       }

}
void stringfunc()
{
	// Variable Declarations here
	
	int num , z;
	char word[100][50];
	char string[100],string2[100];
	char des[50], source[50];
	char str1[20], str2[20];
	/*                */
	    int option;
	    printf("\tSTRING FUNCTIONS\n");
        printf("1. Length -- strlen();\n");
        printf("2. Concatenation -- strcat();\n");
        printf("3. String Copy -- strcpy();\n");
        printf("4. String Compare -- strcmp();\n");
        printf("5. Exit this station\n");
        printf("\nPlease enter number of choice\n");
        printf("Your choice is :");
        scanf("%i",&option);
        printf("\n\n");
        system("cls");
        switch(option)
            {
            case 1:
        printf("Enter how many strings you want :(\n");
        scanf("%i",&num);
        printf("Go type your strings\n");
        for(z=0; z < num; z++)
            { 
                printf("Word %i = ",z);
                scanf("%s",word[z]);
                printf("\n");
            }
            printf("\n");
            printf("Output:\n");
        for(z=0; z < num; z++)
            {
             int len = strlen(word[z]); 
                printf("The lenght of Word[%i]-> %s = %i\n",z,word[z],len);
            }
            printf("\n\n");
            stringfunc();
            break;
            case 2:
	        printf("Enter your 2 strings\n");
	        printf("String 1?\n");
            scanf("%s",string);
            printf("String 2?\n");
            scanf("%s",string2);
            strcat(string,string2);
            printf("\n");
            printf("Output: ");
            printf("Your new string is %s\n\n",string);
            printf("\n\n");
            stringfunc();
            break;
            case 3:
            printf("Enter your 1st string\n");
            scanf("%s",source);
            printf("Now string 2 will copy what's on string 1\n");
            strcpy(des,source);
            printf("\n");
            printf("Output: ");
            printf("String 1 is %s\t,String 2 is %s\n",source,des);
            printf("\n\n");
            stringfunc();
            break;
     	    case 4:
            printf("Enter your 2 strings\n");
            printf("String 1?\n");
            scanf("%s",str1);
            printf("String 2?\n");
            scanf("%s",str2);
            if(strcmp(str1,str2)==0)
            {
            printf("\n");
            printf("Output:\t");
            printf("They are equal, nothing more nothing less\n");
            } else 
			if(strcmp(str1,str2) < 0)
            {
            printf("\n");
            printf("Output:\t");
            printf("1st: %s ,2nd: %s\n",str1,str2);
            } else 
			if(strcmp(str1,str2) > 0)
            {
            printf("\n");
            printf("Output:\t");
            printf("1st: %s  , 2nd: %s\n",str2,str1);
            }
			printf("\n\n");
            stringfunc();
	        break;
	        case 5:
	        default:
	        system("cls");
            choiceko();
            break;
	    }
}
void winsert()
{
   char names[100][100];
    char item[20];
    int elem;
    int c;
    int a;
    int i1;
    int loc;
    int ch;
               printf("\tString Insert\n");
               printf("How many names do you want to Enter?\n");
               scanf("%i",&elem);
               printf("Enter your names\n");
               for(i1=0; i1 < elem; i1++)
               {
               printf("Name [%i] = \n",i1);
               scanf("%s",names[i1]);
               }
               printf("Enter the location you want to insert\n");
               scanf("%i",&loc);
               printf("Enter the name you want to insert\n");
               scanf("%s",item);
               for(c = elem; c >=loc -1 ; c--)
               {
               strcpy(names[c+1],names[c]);
               }
               strcpy(names[loc -1],item);
               printf("This is now your new set of names\n");
               for(a=0; a <= elem; a++)
               {
               printf("Name[%i] = %s\n",a,names[a]);
               }
               printf("Do you want to exit?\n");
               printf(" 1 (YES) or 0 (NO)\n");
               printf("Choice: ");
               scanf("%i",&ch);
                 switch(ch)
                  {
                    case 1:
                    system("cls");
                    wordproc();
                    break;
                    case 0:
                    winsert();
		    break;
                   }
}
void wdelete()
{
     char names1[100][100];
    int elem1;
    int count;
    int i;
    int loc1;
    int x;
    int ch;
 	      printf("\tString Delete\n");
	      printf("How many names do you want enter?\n");
              scanf("%i",&elem1);
              printf("Enter those names\n");
              for(i=0; i < elem1; i++)
              {
              printf("Name[%i] = \n",i);
              scanf("%s",names1[i]);
              }
              printf("Enter the location that you want to DELETE\n");
              scanf("%i",&loc1);
              for(x = loc1 -1 ; x <= elem1 -1 ; x++)
              {
              strcpy(names1[x],names1[x+1]); 
              }
              printf("This are your new set of names\n");
              for(count = 0; count < elem1 -1 ; count ++)
              {
              printf("Names[%i] = %s\n",count,names1[count]);
              }
              printf("Do you want to exit?\n");
               printf(" 1(YES) or 0(NO)\n");
               printf("Choice: ");
               scanf("%i",&ch);
                 switch(ch)
                  {
                    case 1:
                    system("cls");
                    wordproc();
                    break;
                    case 0:
                    wdelete();
		    break;
                   }
}
void wsearch()
{
    char names2[100][100];
    int elem2;
    int count2;
    char item2[20];
    int loc2;
    int c2;
    int c;
    int ch;
              printf("\tString Search\n");
 	          printf("Enter how many names do you want?\n");
              scanf("%i",&elem2);
              printf("Enter those names\n");
              for(count2 = 0; count2 < elem2; count2++)
              {
              printf("Name[%i] = \n",count2);
              scanf("%s",names2[count2]);
              }
              printf("Enter the names you want to search\n");
              scanf("%s",item2);
              for(loc2 = 0; loc2 < elem2; loc2++)
              {
              if(strcmp(names2[loc2],item2) == 0)
              {
              printf("Fount it at location %i = %s\n",loc2,names2[loc2]);
              c++;
              }
              }
              if (c == 0)
              {
              printf("Error: 404! Name not found!\n");
              }
              printf("Do you want to exit?\n");
               printf(" 1(YES) or 0(NO)\n");
               printf("Choice: ");
               scanf("%i",&ch);
                 switch(ch)
                  {
                    case 1:
                    system("cls");
                    wordproc();
                    break;
                    case 0:
                    wsearch();
		            break;
                   }
}
int strall()
{
	char words[100][100];
  	char item[20];
  	char temp[20];
  	int elem;
  	int i;
  	int loc;
  	int c =0;
  	int choice;
  	int b;
  	int d;
  	
  	  printf("Create a set of words/string array\n");
  	  printf("Creating...\n");
  	  printf("Please how many elements you want:\n");
  	  printf("Elements: ");
  	  scanf("%i",&elem);
  	  printf("Please enter your corresponding words/strings:\n");
  	  for(i=0; i < elem; i++)
  	  {
  	     printf("Word[%i]: ",i);
		 scanf("%s",words[i]);
	  }
	  printf("\n\n");
	       while(choice != 5)
	       {
	       	    printf("\n");
	       	    printf("\t\nPlease choose what to perform:\n");
	       	    printf("1. Insertion\n");
	       	    printf("2. Deletion\n");
	       	    printf("3. Linear Search\n");
	       	    printf("4. Bubble Sort\n");
	       	    printf("5. Exit\n");
	       	    printf("Choice: \n");
	       	    scanf("%i",&choice);
	       	        switch(choice)
	       	        {
	       	           case 1:
	       	           	if(elem >= 10)
	       	           	{
	       	           	   system("cls");
						   printf("There is no more space to insert PS: OVERFLOW!!!\n");
						   return 0;		 	
						}
						printf("\tInserting..\n");
						printf("Enter the location you want to insert: \n");
						printf("Location: ");
						scanf("%i",&loc);
						printf("\n");
						printf("Enter the item you want to insert: \n");
						printf("Item: ");
						scanf("%s",item);
						for(i=elem; i >= loc -1; i--)
						{
							strcpy(words[i+1],words[i]);
						}
						strcpy(words[loc -1 ], item);
						printf("Your new set of arrays: \n");
						elem++;
						for(i=0; i < elem; i++)
						{
							printf("Words[%i]: ",i);
							printf("%s",words[i]);
							printf("\n");
						}	  
					   break;
					   case 2:
					   	if(elem == 0)
					   	{
					   	   system("cls");
						   printf("Array is empty, there is nothing to delete PS: UNDERFLOW!!!\n");
						   return 0;	
						}
					    printf("\tDeleting...\n");
						printf("Enter the location you wat to delete: \n");
						printf("Location: ");
						scanf("%i",&loc);
						for(i=loc -1 ; i < elem;i++)
						{
							strcpy(words[i],words[i+1]);
						}
						printf("Your new set of arrays: \n");
						elem--;
						for(i = 0; i <= elem -1 ; i ++)
              				{
              				   printf("Words[%i]: ",i);
              				   printf("%s",words[i]);
								printf("\n");
              			    }
					   break;
					   case 3:
					    printf("\tSearching...\n");
						printf("Enter the word/string you want to search\n");
						printf("Item: ");
	                    scanf("%s",item);
	                    c = 0;
    				    for(i=0; i <= elem; i++)
     					{
    	   				   if(strcmp(words[i],item) == 0)
    	 				    {
    	      			       printf("We found it on location[%i] = %s\n",i,words[i]);
    	      			       c++;
	       				    } 
	   					}
	   					if(c==0)
	   					{
	   						printf("Error! Your item can't be found\n");
	   						printf("\n");
						   }
					   break;
					   case 4:
					   printf("\nSorting...\n");
	        			for(b=0; b < elem; b++)
	        			{
	        				for(d=0; d < elem; d++)
	        				{
	        					if(strcmp(words[b],words[d]) < 0)
								{
									strcpy(temp,words[b]);
									strcpy(words[b],words[d]);
									strcpy(words[d],temp);
								}
							}
						}
						printf("\tAfter Bubble Sort Operation:\n");
						printf("Sorted:");
		 				for(i=0; i < elem; i++)
		 				{
		     				printf("\nWords[%i]: ",i);
			 				printf("%s",words[i]);	
		 				}		
					   break;
					   case 5:
					   default:
					   system("cls");	
					   wordproc();
					   break;  	
					}
		   }
}
void wbubblesort()
{
	char words[100][30];
	int num;
	int b;
	int c;
	int i;
	char temp[20];
	int ch;
	
	   printf("\tString Bubble Sort\n");
	   printf("Enter how many words/strings you want:\n");
	   printf("Elements: ");
	   scanf("%i",&num);
	   printf("Enter your corresponding words/strings:\n");
	   for(i =0; i < num; i++)
	   {
	   	  printf("Word[%i]: ",i);
	   	  scanf("%s",words[i]);
	   }
	   printf("\nSorting...\n");
	        for(b=0; b < num; b++)
	        {
	        	for(c=0; c < num; c++)
	        	{
	        		if(strcmp(words[b],words[c]) < 0)
						{
							strcpy(temp,words[b]);
							strcpy(words[b],words[c]);
							strcpy(words[c],temp);
						}
				}
			}
		printf("\tAfter Bubble Sort Operation:\n");
		printf("Sorted:\n");
		 for(i=0; i < num; i++)
		 {
		     printf("\nWords[%i]: ",i);
			 printf("%s",words[i]);	
		 }
        printf("\nDo you want to exit?\n");
        printf(" 1(YES) or 0(NO)\n");
        printf("Choice: ");
        scanf("%i",&ch);
            switch(ch)
            {
            case 1:
            system("cls");
            wordproc();
            break;
            case 0:
            wbubblesort();
		    break;
            }	
}
void wordproc()
{
	
	 int option;
     int ch;
	   printf("\tWORD PROCESSING\t\n");
	   printf("1. STRING INSERTION\n");
	   printf("2. STRING DELETION\n");
	   printf("3. STRING LINEAR SEARCH\n");
	   printf("4. STRING BUBBLE SORT\n");
	   printf("5. STRING SINGLE ARRAY PROCESS\n");
	   printf("6. Exit this station\n");
	   printf("Please enter your choice\n");
	   scanf("%i",&option);
	   system("cls");
	       switch(option)
	       {
	       	case 1:
	       	winsert();
	        break;
		    case 2:
		   	wdelete();
	        break;
	        case 3:
	      	wsearch();
		    break;
		    case 4:
		    wbubblesort();
			break;
			case 5:
			strall();
			break;	
			case 6:
			default:
			system("cls");
			choiceko();
			break;	
		   }
}
void intsert()
{
	int numero[100];
	int pira;
	int daka;
	int loca;
	int item;
	int c,y;
	int ch;
	    
	    printf("\t Integer insertion\n");
	    printf("Enter the numbers of elemets\n");
	    scanf("%i",&pira);
	    printf("Enter those numbers\n");
	    for(daka=0; daka < pira; daka++)
	    {
		    scanf("%i",&numero[daka]);
	    }
	    printf("Enter the location you want to insert\n");
	    scanf("%i",&loca);
	    printf("Enter the number you want to insert\n");
	    scanf("%i",&item);
	        for(c= pira; c >= loca-1; c--)
	        {
	        	numero[c+1] = numero[c];
	        }
	    numero[loca-1] = item;
	    printf("This is your new set of arrays\n");
	        for(y=0; y  <= pira; y++)
	        {
	            printf("numero[%i] = %i\n",y,numero[y]);	
	        }
	        printf("Do you want to exit?\n");
            printf(" 1(YES) or 0(NO)\n");
            printf("Choice: ");
            scanf("%i",&ch);
                switch(ch)
                {
                case 1:
                system("cls");
                intproc();
                break;
                case 0:
                intsert();
		        break;
                }    
	    
}
void intdel()
{
	int numbers[100];
	int indakadaw;
	int a;
    int location;
    int n;
    int count;
    int ch;
       
        printf("\tInteger Deletion\n");
        printf("Enter how many numbers you want\n");
	    scanf("%i",&indakadaw);
	    printf("Enter those numbers\n");
	        for(a=0; a < indakadaw; a++)
	        {
                scanf("%i",&numbers[a]);
	        }
	        printf("Enter the location of your numbers that you want to delete\n");
	        scanf("%i",&location);
	        for(n=location-1; n <= indakadaw -1; n++)
	        {
	            numbers[n] = numbers[n+1];
	        }
	        printf("Your new set of arrays are\n");
	        for(count=0; count < indakadaw-1; count++)
	        {
	            printf("numbers[%i] = %i\n",count,numbers[count]);
	        } 
	        printf("Do you want to exit?\n");
            printf(" 1(YES) or 0(NO)\n");
            printf("Choice: ");
            scanf("%i",&ch);
            switch(ch)
            {
            case 1:
            system("cls");
            intproc();
            break;
            case 0:
            intdel();
		    break;
            }    
}
void intsrch()
{
	int daeman[100];
    int aw;
    int bum=0;
    int locat;
    int data;
    int disc;
    int ch;
    
    printf("\tInteger Searching\n");
    printf("Enter your number of  elements\n");
    scanf("%i",&aw);
    printf("Enter those numbers\n");
        for(disc=0; disc < aw; disc++)
        {
    	    scanf("%i",&daeman[disc]);
	    }	
	printf("Enter the number you want to search\n");
	scanf("%i",&data);
        for(locat=0; locat < aw; locat++)
        {
    	    if(daeman[locat] == data)
    	    {
    	        printf("We found it on location[%i] = %i\n",locat,daeman[locat]);
                bum++;
	        } 
	    }
	        if(bum == 0)
	            {
                    printf("We can't find it\n");
	            }
	        printf("Do you want to exit?\n");
            printf(" 1(YES) or 0(NO)\n");
            printf("Choice: ");
            scanf("%i",&ch);
                switch(ch)
                {
                case 1:
                system("cls");
                intproc();
                break;
                case 0:
                intsrch();
		        break;
                }           
}
int intall()
{
	int arrays[100];
	int elem;
	int loc;
	int i;
	int choice;
	int item;
	int c=0;
	int idx;
	int op;
	int b;
	int d;
	int temp;
	int counter;
	   
	   printf("Create a set of integer arrays:\n");
	   printf("Creating...\n");
	   printf("Please enter the elements you want:\n");
	   printf("Elements: ");
	   scanf("%i",&elem);
	   printf("Enter your corresponding numbers:\n");
	   for(i=0; i < elem; i++)
	   {
	   	printf("Number[%i]: ",i);
	   	scanf("%i",&arrays[i]);
	   }
	   printf("\n\n");
	            while(choice != 5)
	            {
	         	printf("\t\nPlease choose what to perform:\n");
	         	printf("1. Insertion\n");
	         	printf("2. Deletion\n");
	         	printf("3. Linear Search\n");
	         	printf("4. Bubble Sort\n");
	         	printf("5. Exit\n");
	         	printf("Choice: ");
	         	scanf("%i",&choice);
	         	       switch(choice)
	         	       {
						case 1:
						if(elem >= 10)
						{
						 	system("cls");
						 	printf("There is no more space to insert PS: OVERFLOW!!!\n");
						 	printf("\n");
				            return 0;
						}	
						printf("\tInserting..\n");
						printf("Enter the location you want to insert: \n");
						printf("Location: ");
						scanf("%i",&loc);
						printf("\n");
						printf("Enter the item you want to insert: \n");
						printf("Item: ");
						scanf("%i",&item);
						for(i=elem; i >= loc -1; i--)
						{
							arrays[i+1] = arrays[i];
						}
						arrays[loc-1] = item;
						printf("Your new set of arrays: \n");
						elem++;
						for(i=0; i < elem; i++)
						{
							printf("Number[%i]: ",i);
							printf("%i",arrays[i]);
							printf("\n");
						}
						break;
						case 2:
						if(elem == 0)
						{
							system("cls");
							printf("Array is Empty , there is nothing to delete PS: UNDERFLOW!!!\n");
							return 0;
						}
						printf("\tDeleting...\n");
						printf("Enter the location you wat to delete: \n");
						printf("Location: ");
						scanf("%i",&loc);
						for(i=loc -1 ; i < elem;i++)
						{
							arrays[i] = arrays[i+1];
						}
						printf("Your new set of arrays: \n");
						elem--;
						for(i = 0; i <= elem -1 ; i ++)
              				{
              				   printf("Numbers[%i]: ",i);
              				   printf("%i",arrays[i]);
              				   printf("\n");
              			    }
						break;
						case 3:	
						printf("\tSearching...\n");
						printf("Enter the number you want to search\n");
						printf("Item: ");
	                    scanf("%i",&item);
	                    c = 0;
    				    for(idx=0; idx <= elem; idx++)
     					{
    	   				   if(arrays[idx] == item)
    	 				    {
    	      			       printf("We found it on location[%i] = %i\n",idx,arrays[idx]);
               			        c++;
	       				      } 
	   					}
	   					if(c==0)
	   					{
	   						printf("Error! Your item can't be found\n");
	   						printf("\n");
						   }
						break;
						case 4:
						printf("\nSorting...\n");
						for(b=0; b < elem; b++)
        				{
            				for(d=0; d < elem; d++)
                			{
                  				if(arrays[b] < arrays[d])
                  					{
                  						temp = arrays[b];
                  						arrays[b] = arrays[d];
                  	     				arrays[d] = temp;
									}
							}
        				}
        				printf("\nAfter Bubble Sort Operation:\n");
       					printf("Sorted: \n");
       					for(counter = 0; counter < elem; counter++)
	   						{
	   	  						printf("Numbers[%i]: ",counter);
	   	  						printf("%i",arrays[counter]);
	   	  						printf("\n");
	   						}
						break;
						case 5:
						default:
						system("cls");
						intproc();
						break;	
						}	
			      }
}
void intbubblesort()
{
	int arrays[100];
	int b;
	int c;
	int counter;
	int temp;
	int num;
	int ch;
	
	printf("\tInteger BUBBLE SORT\n");
	printf("Enter how many elements you want:\n");
	printf("Element/s: ");
	scanf("%i",&num);
	printf("Enter your corresponding numbers:\n");
	for(counter=0; counter < num; counter++)
	{
		printf("Number[%i]: ",counter);
		scanf("%i",&arrays[counter]);
	}
	printf("\nSorting...\n");
	  for(b=0; b<num; b++)
        {
            for(c=0; c<num; c++)
                {
                  	if(arrays[b] < arrays[c])
                  	{
                  		temp = arrays[b];
                  		arrays[b] = arrays[c];
                  	    arrays[c] = temp;
						}
				}
        }
       printf("\nAfter Bubble Sort Operation:\n");
       printf("Sorted: \n");
       for(counter = 0; counter < num; counter++)
	   {
	   	  printf("Numbers[%i]: ",counter);
	   	  printf("%i",arrays[counter]);
	   	  printf("\n");
	   }
	    printf("Do you want to exit?\n");
        printf(" 1(YES) or 0(NO)\n");
        printf("Choice: ");
        scanf("%i",&ch);
            switch(ch)
            {
            case 1:
            system("cls");
            intproc();
            break;
            case 0:
            intbubblesort();
		    break;
                } 
}
void intproc()
{

	int option;
	    printf("\tINTEGER PROCESSING\n");
        printf("1. INT INSERTION\n");
        printf("2. INT DELETION\n");
        printf("3. INT LINEAR SEARCH\n");
        printf("4. INT BUBBLE SORT\n");
        printf("5. INT SINGLE ARRAY PROCESS\n");
        printf("6. Exit this station\n");
        printf("Enter number of your choice\n");
        scanf("%i",&option);
        system("cls");
           switch(option)
           {
           	case 1:
            intsert();
		    break;
		    case 2:
		    intdel();
		    break;
		    case 3:
		    intsrch();
		    break;
		    case 4:
		    intbubblesort();
		    break;
		    case 5:
		    intall();
		    break;	
		    case 6:
		    default:
		    system("cls");
		    choiceko();
		    break;
		   }
}
//
int intstck()
{
	int arrays[10];
	int i = -1;
	int c;
	int num;
	int choice;
	
	  printf("\tInteger Stacks - Push and Pop\n");
	  printf("Note: In Stacks we follow LIFO - Last In , Fist out\n");
	  while(choice != 3)
	  {
	  	printf("\nPlease choose what to perform:\n");
	  	printf("1. Push\n");
	  	printf("2. Pop\n");
	  	printf("3. Exit this station\n");
	  	printf("Choice: ");
	  	scanf("%i",&choice);
	  	     switch(choice)
	  	     {
	  	        case 1:
				  if(i > 10)
				  {
				  	 system("cls");
				     printf("Array is full PS: OVERFLOW!!!\n");
					 printf("\n");
					 return 0;
				  }	
				  printf("\n\tPush\n");
				  printf("\nEnter an integer to push\n");
				  printf("Integer: ");
				  scanf("%i",&num);
				  arrays[i+1] = num;
				  i++;
				  for(c =i; c >= 0; c--)
				  {
				  printf("*******\n");
				  printf(" %i ",arrays[c]);
				  printf("\n*******");
				  printf("\n");
			      }
				break; 
				case 2:
				if(i == -1)
				{
				  system("cls");
				  printf("Array is Empty! PS: UNDERFLOW!!!\n");	
				  printf("\n");
				  return 0;
				}	
				printf("\n\tPop\n");
				num = arrays[i];
		        printf("\nThe element popped was %i\n",num);
		        printf("After pop operation: \n");
		        i--;
		        for(c= i; c >= 0; c--)
		        {
		          printf("*******\n");
				  printf(" %i ",arrays[c]);
				  printf("\n*******");
				  printf("\n");
				}
				break;
				case 3:
				default:
				system("cls");
				stacks();
				break; 	
		     }
	  }
}
int strstck()
{
	char words[100][100];
	int i = -1;
	int c;
	char item[20];
	int choice;
	
	  printf("\tString Stacks - Push and Pop\n");
	  printf("Note: In Stacks we follow LIFO - Last In , Fist out\n");
	  while(choice != 3)
	  {
	  	printf("\nPlease choose what to perform:\n");
	  	printf("1. Push\n");
	  	printf("2. Pop\n");
	  	printf("3. Exit this station\n");
	  	printf("Choice: ");
	  	scanf("%i",&choice);
	  	     switch(choice)
	  	     {
	  	        case 1:
				  if(i > 10)
				  {
				  	 system("cls");
				     printf("Array is full PS: OVERFLOW!!!\n");
					 printf("\n");
					 return 0; // or set i = 0; to stop the Full exit problem, change it if have time
					 	
				  }	
				  printf("\n\tPush\n");
				  printf("\nEnter a word/string to push\n");
				  printf("Item: ");
				  scanf("%s",item);
				  strcpy(words[i+1],item);
				  i++;
				  for(c =i; c >= 0; c--)
				  {
				  printf("*******\n");
				  printf(" %s ",words[c]);
				  printf("\n*******");
				  printf("\n");
			      }
				break; 
				case 2:
				if(i == -1)
				{
				  system("cls");	
				  printf("Array is Empty! PS: UNDERFLOW!!!\n");	
				  printf("\n");
				  return 0;
				}	
				printf("\n\tPop\n");
				strcpy(item,words[i]);
		        printf("\nThe string/word popped was %s\n",item);
		        printf("After pop operation: \n");
		        i--;
		        for(c= i; c >= 0; c--)
		        {
		          printf("*******\n");
				  printf(" %s ",words[c]);
				  printf("\n*******");
				  printf("\n");
				}
				break;
				case 3:
				default:
				system("cls");	
				stacks();
				break; 	
		     }
	  }
}
void stacks()
{
	int choice;
     printf("\tSTACKS\n");
	 printf("Please enter your choice:\n");
	 printf("1. Integer Stacks\n");
	 printf("2. String Stacks\n");
	 printf("3. Exit this station\n");
	 printf("Choice: ");
	 scanf("%i",&choice);
	 system("cls");
	      switch(choice)
		  {
		    case 1:
			intstck();
			break;
			case 2:
			strstck();
			break;
			case 3:
			default:
			system("cls");
			printarr();	
			break;	
		  } 
}
// FUNCTION FOR LINK LIST
void linklist()
{
	   int input = 1;
       int retval = 0 , num = 0;
       struct NODE *llist;
       llist = (struct NODE *) malloc(sizeof(struct NODE));
       llist->number = 0;
       llist->next = NULL;
       
                while(input != 0)
                {
	            printf("\n--MENU SELECTION--\n");
                printf(" 0) QUIT\n");
                printf(" 1) INSERT\n");
                printf(" 2) DELETE\n");
                printf(" 3) SEARCH\n");
                printf(" 4) DISPLAY\n");
                printf("NOTE: Just press the choice 0 to exit this level\n");
                printf("Enter the number of your choice\n");
                scanf("%i",&input);
                   switch(input)
                   {
                case 0:
                default:
                system("cls");
                printarr();
                break;
                case 1:
                printf("Your choice : 'Insertion'\n");
                printf("Enter the value you want to insert\n");
                scanf("%i",&num);
                append_node(llist,num);
                break;
                case 2:
                printf("Your choice: 'Deletion'\n");
                printf("Enter the value which you want to delete\n");
                scanf("%i",&num);
                delete_node(llist,num);
                break;
		        case 3:
		        printf("Your choice : 'Search'\n");
                printf("Enter the value you want to find:\n");
                scanf("%i",&num);
                if((retval = search_value(llist,num)) == -1 )
                { 
                printf("Value not found\n");
                } else
                {
                printf("Value %i , located at %i\n",num,retval);
                }
                break;
	            case 4:
		        printf("Your choice : 'Display'\n");
                display_list(llist);
				break;       	
		        }
            }
            free(llist);
}
// THIS STATION IS THE FUNCTIONS FOR LINK LISTS PART
void display_list(struct NODE *llist)
{
       while(llist->next != NULL)
            {
              printf("%i\n",llist->number);
              llist = llist->next;
             }
         printf("Your number %i\n" , llist->number);
} 
void append_node(struct NODE *llist, int num)
{
            while(llist->next != NULL)
              {
               llist = llist->next;
               }
            llist->next = (struct NODE *) malloc(sizeof(struct NODE));
            llist->next->number = num;
            llist->next->next = NULL;
} 
void delete_node(struct NODE* llist, int num)
{
            struct NODE *temp;
            temp = (struct NODE *) malloc(sizeof(struct NODE));
            
            if(llist->number == num)
            { /* remove the node */ 
             temp = llist->next;
             free(llist);
             llist = temp;
             } else
             {
               while(llist->next->number != num)
               { 
                 llist = llist->next;
                }
                 temp = llist->next->next;
                 free(llist->next);
                 llist->next = temp; 
              }
} 
 int search_value(struct NODE *llist, int num)
{
  int retval = -1;
  int i = 1;
  while(llist->next !=NULL)
    {
       if(llist->next->number == num)
           {
             return i;
            } else 
            { 
                i++;
             }
       llist = llist->next;
     }
    return retval;
}
int lqueint()
{
	int arrays[10];
	int front = 0;
	int choice;
	int item;
	int rear = 0;
	int i;
	
	    while(choice != 4)
	    {
	    	printf("\n\tInteger Linear Queue\n");
	    	printf("Choices:\n");
	    	printf("1. Enqueue - Add item\n");
	    	printf("2. Dequeue - Remove item\n");
	    	printf("3. Display Queue\n");
	    	printf("4. Exit\n");
	    	printf("Please enter your choice:\n");
	    	printf("Choice: ");
	    	scanf("%i",&choice);
	    	    switch(choice)
	    	    {
	    	    	case 1:
	    	    	if(front >= 10)
	    	    	{
	    	    		printf("\n");
	    	    		printf("No more space for insertion!\n");
	    	    		printf("The Array is FULL PS: OVERFLOW!!!\n");
	    	    		return 0;
					}
	    	    	printf("\tEnqueue\n");
					printf("Please enter the item you want to insert:\n");
					printf("Item: ");
					scanf("%i",&item);
					arrays[front] = item;
					front++;
	    	    	break;
					case 2:
					if(front == rear)
					{
					   printf("\n");
					   printf("There's nothing more to delete!\n");
					   printf("The Array is EMPTY PS: UNDERFLOW!!!\n");
				 	   return 0;
					}	
					item = arrays[0]; // update
					for(i=0; i <= front-1 ; i++)
					{
						arrays[i] = arrays[i+1];
					}
					front--;
					printf("The item deleted was: %i",item);
					break;
					case 3:
					printf("\tDisplay\n");
					printf("\nThe queue elemets: "); 
					for(i=0; i <= front-1; i++)
					{
					  printf("%i ",arrays[i]);	
					}	
					break;
					case 4:
					default:
					system("cls");
					linque();
					break;	
				}
		} 
}
int lquestr()
{
	char words[100][100];
	int front = 0;
	int choice;
	char item[20];
	int rear = 0;
	int i;
	
	    while(choice != 4)
	    {
	    	printf("\n\tString Linear Queue\n");
	    	printf("Choices:\n");
	    	printf("1. Enqueue - Add item\n");
	    	printf("2. Dequeue - Remove item\n");
	    	printf("3. Display Queue\n");
	    	printf("4. Exit\n");
	    	printf("Please enter your choice:\n");
	    	printf("Choice: ");
	    	scanf("%i",&choice);
	    	    switch(choice)
	    	    {
	    	    	case 1:
	    	    	if(front >= 10 )
	    	    	{
	    	    		printf("\n");
	    	    		printf("No more space for insertion!\n");
	    	    		printf("The Array is FULL PS: OVERFLOW!!!\n");
	    	    		return 0;
					}
	    	    	printf("\tString Enqueue\n");
					printf("Please enter the item you want to insert:\n");
					printf("Item: ");
					scanf("%s",item);
					strcpy(words[front],item);
					front++;
	    	    	break;
					case 2:
					if(front == rear)
					{
					   printf("\n");
					   printf("There's nothing more to delete!\n");
					   printf("The Array is EMPTY PS: UNDERFLOW!!!\n");
				 	   return 0;
					}	
					strcpy(item,words[0]); // update for deleted item
					for(i=0; i <= front-1 ; i++)
					{
						strcpy(words[i],words[i+1]);
					}
					front--;
					printf("The item deleted was: %s",item);
					break;
					case 3:
					printf("\tDisplay\n");
					printf("\nThe queue elemets: "); 
					for(i=0; i <= front-1; i++)
					{
					  printf("%s ",words[i]);	
					}	
					break;
					case 4:
					default:
					system("cls");
					linque();
					break;	
				}
		}
}
void linque()
{
	int choice;
	
	printf("\tLinear Queue\n");
	printf("1. Integer Linear Queue\n");
	printf("2. String Linear Queue\n");
	printf("3. Exit this station\n");
	printf("Please enter your choice: \n");
	printf("Choice: ");
	scanf("%i",&choice);
		switch(choice)
		{
			case 1:
			lqueint();	
			break;
			case 2:
			lquestr();
			break;
			case 3:
			default:
			system("cls");
			queue();
			break;	
		}
}
void queue()
{
    int op;
	printf("\tQUEUES\t\n");
	printf("1. Linear Queue\n");
	printf("2. Circular Queue\n");
	printf("3. Exit this station\n");;
	printf("Enter your choice for Queue\n");
	printf("Choice: ");
	scanf("%i",&op);
	system("cls");
	    switch(op)
	    {
	    	case 1:
	    	linque();
			break;
			case 2:
			cirque();
			break;
			case 3:
			default:
			system("cls");
			printarr();
			break;	
		}
}
void strque()
{
	char words[100][100];
	int elem;
	int i;
	int j;
	char item[20];
	int choice;
	printf("\tString Queues\t\n");
	printf("Enter the number of words you want\n");
	printf("Input: ");
	scanf("%i",&elem);
	printf("Enter your specific words\n");
	for(i=elem,j=1; i!='\0'; i--,j++)
	{
		printf("[%i] = ",j);
		scanf("%s",words[i]);
	}
	printf("This were your words:\n");
	printf("||");
	for(i=1; i <= elem; i++)
	{
		printf("%s\t",words[i]);
	}
	printf("||");
	  while(choice != 2)
	  {
	  	printf("\n\tEnter your choice:\t\n");
	  	printf("\n1. Insert item in queue\n");
	  	printf("\n2. Exit queue\n");
	  	printf("Choice: ");
	  	scanf("%i",&choice);
	        switch(choice)
	        {
	        case 1:	
	          printf("Enter your item to insert the Queue\n");
	          printf("Item: ");
		      scanf("%s",item);  
		      for(i=elem; i!='\0'; i--)
				{
				   strcpy(words[i],words[i-1]);
					if(i==1)
					{
						strcpy(words[i],item);
					}
				}	
			   printf("Queue.. ");
			   	for(i=1; i<=elem; i++)
			   	{
			   	    printf("%s\t",words[i]);	
			    }
			    printf("\n");
			break;
			case 2:
			default:
			system("cls");
			cirque();
			break;	
			}
	     }
}
void intque()
{
	int array[100];
	int num;
	int i,j;
	int item;
	int choice;
	printf("\tInteger QUEUES\t\n");
	printf("Enter how many numbers you want:\n");
	printf("How many? : ");
	scanf("%i",&num);
	printf("\n");
	printf("Enter your specific numbers:\n");
	for(i=num,j=1; i!='\0'; i--,j++)
	{
		printf("[%i]= ",j);
		scanf("%i",&array[i]);
	}
	printf("This were your numbers:\n");
	printf("||\t");
	for(i=1; i <= num; i++)
	{
		printf("%i\t",array[i]);
	}
	printf("||");
	while(choice != 2)
	{
		printf("\n\tEnter your choice\t\n");
		printf("\n1. Insert for Queue\n");
		printf("\n2. Exit queue\n");
		printf("Your choice : ");
		scanf("%i",&choice);
		   switch(choice)
		  {
		case 1:
		printf("Enter your item to insert the Queue\n");
		scanf("%i",&item);  
		for(i=num; i!='\0'; i--)
		{
			array[i] = array[i -1];
			if(i==1)
			{
				array[i] = item;
			}
		}
		printf("Queue.. ");
		for(i=1; i <=num; i++)
		{
			printf("%i\t",array[i]);
		}
		break;
		case 2:
		default:
		system("cls");
		cirque();
		break;
	     }
		
      }
}
void cirque()
{
	int option; 
	
	printf("\tCircular Queue\n");
	printf("1. Integer Circular Queue\n");
	printf("2. String Circular Queue\n");
	printf("3. Exit this station\n");
	printf("Please enter your choice: \n");
	printf("Choice: ");
	scanf("%i",&option);
	     switch(option)
	     {
	     	case 1:
	     	intque();
			break; 	
			case 2:
			strque();	
			break;
			case 3:
			default:
			system("cls");
			queue();
			break;
		 }
}
// Choice 'b' functions here
void printarr()
{
	 int option;
	 // Variable Declarations station
	   int x[100],elem1 , i;
	   int array[100];
       int elem,loc , t;
       
      //
      int input = 1;
       int retval = 0 , num = 0;
       struct NODE *llist;
       llist = (struct NODE *) malloc(sizeof(struct NODE));
       llist->number = 0;
       llist->next = NULL;
       
         printf("\tARRAYS\n");
         printf("1. How to print a line of Arrays\n");
         printf("2. TRAVERSAL - Access the location of an Array\n");
         printf("3. Link Lists:\n");
         printf("4. Stacks\n");
         printf("5. Queues\n");
         printf("6. Exit this level\n");
         printf("Enter the number of your choice\n");
         scanf("%i",&option);
         system("cls");
         printf("\n");
             switch(option)
             {
             	case 1:
                printf("Enter how many elements\n");
                scanf("%i",&elem1);
                printf("Enter your numbers\n");
                for(i=0; i < elem1; i++)
                {
                printf("Number[%i] = ",i);
                scanf("%i",&x[i]);
                printf("\n");
                }
                printf("This are your ARRAYS\n");
                for(i=0; i < elem1	; i++)
                { 
                printf("location[%i] = %i\n",i,x[i]);
                }
                printf("\n\n");
                printarr();
		        break;
		        case 2:
                printf("Enter your number of elements again\n");
                scanf("%i",&elem);
                printf("Enter your elements\n");
                for(t=0; t < elem ; t++)
                {
                printf("Number[%i] = ",t);
                scanf("%i",&array[t]);
                }
                printf("Enter number of location\n");
                scanf("%i",&loc);
                printf("\n");
                printf("The number of your array is location[%i] = %i\n",loc,array[loc]);
                printf("\n\n");
                printarr();
                break;
	            case 3:
                linklist();
	            break;	
		        case 4:
                stacks();
                break;
                case 5:
                queue();
                break;	
                case 6:
                default:
                system("cls");
                main();
                break;
			 }
    }
