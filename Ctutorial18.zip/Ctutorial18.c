#include<stdio.h>

int main()
{

int arr[3,4] ={

  {11,12,5,43},
  {20,10,1,0},
  {15,13,2,3}


};


int i , j;

for(i=0; i < 3; i++)
{
  
   for(j=0; j < 4; j++)
   {
      printf("%i",arr[i][j]);
   }
   printf("\n");


}




}