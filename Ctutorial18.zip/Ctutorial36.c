#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>

int main()
{
	int arrays[10];
	int i = -1;
	int c;
	int num;
	int choice;
	
	  printf("\tStacks - Push and Pop\n");
	  printf("Note: In Stacks we follow LIFO - Last In , Fist out\n");
	  while(choice != 3)
	  {
	  	printf("\nPlease choose what to perform:\n");
	  	printf("1. Push\n");
	  	printf("2. Pop\n");
	  	printf("3. Exit this station\n");
	  	printf("Choice: ");
	  	scanf("%i",&choice);
	  	     switch(choice)
	  	     {
	  	        case 1:
				  if(i >= 10)
				  {
				     printf("Array is full PS: OVERFLOW!!!\n");
					 return 0;	
				  }	
				  printf("\tPush\n");
				  printf("Enter an integer to push\n");
				  printf("Integer: ");
				  scanf("%i",&num);
				  arrays[i+1] = num;
				  i++;
				  for(c =i; c >= 0; c--)
				  {
				  printf("*******\n");
				  printf(" %i ",arrays[c]);
				  printf("\n*******");
				  printf("\n");
			      }
				break; 
				case 2:
				if(i == -1)
				{
				  printf("Array is Empty! PS: UNDERFLOW!!!\n");	
				  return 0;
				}	
				printf("\tPop\n");
				num = arrays[i];
		        printf("\tThe element popped was %i\n",num);
		        printf("After pop operation: \n");
		        i--;
		        for(c= i; c >= 0; c--)
		        {
		          printf("*******\n");
				  printf(" %i ",arrays[c]);
				  printf("\n*******");
				  printf("\n");
				}
				break;
				case 3:
				
				break; 	
		     }
	  }
}
