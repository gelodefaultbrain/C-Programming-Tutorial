#include<stdio.h>

int main(){




  int i,j,s,key,a[20];




  printf("Enter total elements: ");

  scanf("%d",&s);




  printf("Enter %d elements: ",s);

  for(i=0;i<s;i++)

      scanf("%d",&a[i]);




  for(i=1;i<s;i++){

      key=a[i];

      j=i-1;

      while((key<a[j])&&(j>=0)){

      a[j+1]=a[j];

          j=j-1;

      }

      a[j+1]=key;

  }




  printf("After sorting: ");

  for(i=0;i<s;i++)

      printf(" %d",a[i]);




  return 0;

}
