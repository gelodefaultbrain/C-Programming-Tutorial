#include<stdio.h>

int main()
{

 char words[30][30] = {"Hello","Love","Pogi","Blue"};
 
 int i;

 printf("Please enter 5 strings\n");
 
 for(i=0; i<5; i++)
 { 
    scanf("%s",words[i]);
 }

 printf("After Operations\n");

 for(i=0; i<5; i++)
 {
  printf("Word[%i] = %s\n",i,words[i]);
 }



 /* 

 char words[30][30] = {"Hello","Love","Pogi","Blue"};

 printf("The string is %s",words[2]);

 */


 /*
 char words[30][30] = {"Hello","Love","Pogi","Blue"};

 int i;

 for(i=0; i < 4; i++)
 {
   printf("Words[%i] = %s\n",i,words[i]);
 }
 */

 

}