#include<stdio.h>

int main()
{
 
 //https://www.tutorialspoint.com/cprogramming/c_strings.htm

 //char word[10] = {'H','e','l','l','o','\0'};
 
 char word[20];
 
 printf("Please enter your name:\n");
 scanf("%s",word);

 printf("Hello %s\n",word);

 
  
 /*
 char word[20] = "Hello";

 char letter = word[1]; //getting the letter 'e' (index is 1) from the string "Hello"

 printf("The letter is %c\n",letter); 
 */


}