#include<stdio.h>

int main()
{
 int x = 4;
  
 int *ptr = NULL; //our pointer, always initialize it to NULL

 ptr = &x; // we point our ptr to x

 /*
 Always remember na ang value ng isang pointer is yung address ng
 tinuturo niya (pino-point niya)
 */

 printf("The address of x is %p\n",&x);
 printf("The address of our pointer %p\n",&ptr);
 printf("The value of our pointer is %p",ptr);

}