#include<stdio.h>

struct data
{

 int x;
 char c;
 char string[20];

};
  typedef struct data item;

int main()
{

  //struct data item = {1,'c',"Hi"};

 item a = {100,'c',"Hello"};
  
 printf("Number %i",a.x);

}