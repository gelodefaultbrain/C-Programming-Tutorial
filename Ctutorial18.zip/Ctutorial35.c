#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>

int main()
{
	int arrays[10];
	int front = 0;
	int choice;
	int item;
	int rear = 0;
	int i;
	
	    while(choice != 4)
	    {
	    	printf("\n\tQueue\n");
	    	printf("Choices:\n");
	    	printf("1. Enqueue - Add item\n");
	    	printf("2. Dequeue - Remove item\n");
	    	printf("3. Display Queue\n");
	    	printf("4. Exit\n");
	    	printf("Please enter your choice:\n");
	    	printf("Choice: ");
	    	scanf("%i",&choice);
	    	    switch(choice)
	    	    {
	    	    	case 1:
	    	    	if(front >= 10)
	    	    	{
	    	    		printf("\n");
	    	    		printf("No more space for insertion!\n");
	    	    		printf("The Array is FULL PS: OVERFLOW!!!\n");
	    	    		return 0;
					}
	    	    	printf("\tEnqueue\n");
					printf("Please enter the item you want to insert:\n");
					printf("Item: ");
					scanf("%i",&item);
					arrays[front] = item;
					front++;
	    	    	break;
					case 2:
					if(front == rear)
					{
					   printf("\n");
					   printf("There's nothing more to delete!\n");
					   printf("The Array is EMPTY PS: UNDERFLOW!!!\n");
				 	   return 0;
					}	
					item = arrays[0]; // update
					for(i=0; i <= front-1 ; i++)
					{
						arrays[i] = arrays[i+1];
					}
					front--;
					printf("The item delete was: %i",item);
					break;
					case 3:
					printf("\tDisplay\n");
					printf("\nThe queue elemets: "); 
					for(i=0; i <= front-1; i++)
					{
					  printf("%i ",arrays[i]);	
					}	
					break;
					case 4:
					default:
					
					break;	
				}
		}
}
