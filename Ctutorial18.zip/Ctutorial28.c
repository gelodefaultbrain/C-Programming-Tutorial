#include<stdio.h>

int main()
{
 
 FILE *inputfile = NULL;
 int x;
 inputfile = fopen("try.txt","r"); //r w a

 if(inputfile == NULL)
 {
   printf("Error NO FILE");
   return 0;
 }


 while(fscanf(inputfile,"%i",&x) == 1)
 {
   printf("%i",x);
 }


 fclose(inputfile); //Don't forget to close the file :D

}