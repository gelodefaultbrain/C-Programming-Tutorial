#include<stdio.h>

int main()
{

int number = 2;
int num = 2;

while(number == 0)
{
 printf("Hello while loop");
}

do
{
  printf("Hello do while loop");
}while(num == 0)


}