#include<stdio.h>
#include<string.h>

int main()
{

 /*
  string functions
  
  strlen(); // gets the length of the string , basically how many characters in a string
  strcpy(); // copy another string
  strcat(); // concatenate two strings -> "string1 string2"
  strcmp(); // compares string
  strlwr(); //lowercase the string
  strupr(); //uppercase the string
  strrev(); //reverse the string
 */


 char name[] = "Gels"; 

 int length = strlen(name);

 printf("Length : %i ",length);


 /*
 
 strcpy(name,"Hello World");

 printf("String is %s ",name);



 char str1[] = "Gels";
 char str2[] = "Pogi"; 

 strcat(str1,str2);



 strlwr(str1);
 strupr(str1);
 strrev(string1);


 */


 /*
 char str1[] = "Apple";
 char str2[] = "Zombie";
  

 if(strcmp(str1,str2) < 0)
 {
  printf("Apple Zombie");
 }else
 {
  printf("Zombie Apple");
 }

 */



}