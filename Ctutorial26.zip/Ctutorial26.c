#include<stdio.h>

struct data
{

 int number;
 float num;
 char letter;
 char string[20];
 bool choice;   

};

int main()
{
 
 struct data myData = {2,3.10,'C',"Hello",true};

 myData.num = 1.2;
 myData.choice = false;

 printf("%i\n",myData.choice);

 strcpy(myData.string,"I love you");

 printf("String is %s\n",myData.string);


}