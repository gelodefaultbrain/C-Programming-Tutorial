// own made insertion program got a guide from net but still own made
// take note: num[loc-1] = item; is an array logic, double cancel of the number
// array[3] == 0 1 2 [3];
#include<stdio.h>
main()
{
	int num[100];
	int elem;
	int x;
	int loc;
	int item;
	int c,y;
	printf("Enter the numbers of elemets\n");
	scanf("%i",&elem);
	printf("Enter those numbers\n");
	for(x=0; x < elem; x++)
	{
		scanf("%i",&num[x]);
	}
	printf("Enter the location you want to insert\n");
	scanf("%i",&loc);
	printf("Enter the number you want to insert\n");
	scanf("%i",&item);
	for(c= elem; c >= loc-1; c--)
	{
		num[c+1] = num[c];
	}
	num[loc-1] = item;
	printf("This is your new set of arrays\n");
	for(y=0; y  <= elem; y++)
	{
	  printf("num[%i] = %i\n",y,num[y]);	
	}
}
