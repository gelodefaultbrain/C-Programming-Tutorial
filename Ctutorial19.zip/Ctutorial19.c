#include<stdio.h>
#include<math.h>

int main()
{
 
 /*
  https://www.tutorialspoint.com/c_standard_library/math_h.htm  

  try other functions like
  sqrt();
  fab();
  exp();
 */

 double result = pow();

 printf("Result is equal to %f",result);


}