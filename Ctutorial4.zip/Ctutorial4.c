#include<stdio.h>

int main()
{

int age;
//char letter;

printf("Please enter your age");
scanf("%i",&age);

//scanf("%c",&letter);  //this is for character
//Again I suggest practice with other data types :)

printf("Your age is %i",age);

}