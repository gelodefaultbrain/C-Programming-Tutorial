#include<stdio.h>

int main()
{

 FILE *outputfile = NULL;

 char string[] = "Gwapo ako";

 int x = 100;

 outputfile = fopen("output.txt","w"); //w means write

 if(outputfile == NULL)
 {
  printf("FILE DOES NOT EXIST");
  return 0;
 }

 fprintf(outputfile,"Hello World File handling in C %s %i",string,x);
 fprintf(outputfile,"\nHello Ladies");
 

}