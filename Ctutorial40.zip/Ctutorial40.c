#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()
{
	int arrays[100];
	int b;
	int c;
	int counter;
	int temp;
	int num;
	
	printf("\tInteger BUBBLE SORT\n");
	printf("Enter how many elements you want:\n");
	printf("Element/s: ");
	scanf("%i",&num);
	printf("Enter your corresponding numbers:\n");
	for(counter=0; counter < num; counter++)
	{
		printf("Number[%i]: ",counter);
		scanf("%i",&arrays[counter]);
	}
	printf("\nSorting...\n");
	  for(b=0; b<num; b++)
        {
            for(c=0; c<num; c++)
                {
                  	if(arrays[b] < arrays[c])
                  	{
                  			temp = arrays[b];
                  			arrays[b] = arrays[c];
                  	     	arrays[c] = temp;
						}
				}
        }
       printf("\nAfter Bubble Sort Operation:\n");
       printf("Sorted: \n");
       for(counter = 0; counter < num; counter++)
	   {
	   	  printf("Numbers[%i]: ",counter);
	   	  printf("%i",arrays[counter]);
	   	  printf("\n");
	   } 
}