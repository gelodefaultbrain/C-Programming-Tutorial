#include<stdio.h>

int main()
{
 int array[] = {3,4,7,2,1};

 int *ptr = NULL;

 //printf("The number of %i\n",*(ptr+2));

 ptr = array;

 int i;

 for(i=0; i<5; i++)
 {
    printf("Number %i\n",*(ptr + i));
 }

}