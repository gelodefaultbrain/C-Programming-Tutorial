#include<stdio.h>

int main()
{

 int a = 2;
 int b = 4;

 int c = a + b; 
 /* 
 You can do other operators
 but make sure the data types is the same!
 especially in float, int and double
 */


 int x = 0;

 x++; //INCREMENT , same as x = x+1;
 
 x--; //DECREMENT , same as x = x-1;



 int result = 2*(1+3)/2;
 /*
 This applies PEMDAS!

 Parenthesis
 Exponents
 Multiplication
 Division
 Addition
 Subtraction 

 */


}