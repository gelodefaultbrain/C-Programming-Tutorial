#include<stdio.h>

int main()
{
 /*
 int myArray[6]= {10,2,4,11,20,1};
 printf("%i",myArray[5]);
 */

 int myArray[20];
 int num;
 int i;

 printf("Please enter how many numbers you want:\n");
 scanf("%i",&num);

 printf("Please enter your numbers:\n");

 for(i=0; i < num;i++)
 {
   scanf("%i",&myArray[i]);
   printf("\n");
 }

 
 printf("After Operation:\n");
 
 for(i=0; i < num; i++)
 {
  printf("%i\n",myArray[i]);
 }


}