#include<stdio.h>

enum days
{
  Monday,
  Tuesday,
  Wednesday,
  Thursday = 20,
  Friday,
  Saturday,
  Sunday
};

int main()
{
 
 int i;
 
 for(i=Monday; i < Sunday; i++)
 {
   printf("%i\n",i);
 }



/*

 enum days  myDays;

 myDays = Thursday;

 printf("%i\n",Monday);
 printf("%i\n",Tuesday);
 printf("%i\n",Wednesday);
 printf("%i\n",Thursday);
 printf("%i\n",Friday);
 printf("%i\n",Saturday);
 printf("%i\n",Sunday);


*/



}