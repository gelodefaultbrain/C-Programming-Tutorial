#include<stdio.h>
#define number 100

int main()
{

int guess;

printf("Enter your guess number\n");
scanf("%i",&guess);

if(guess == number)
{
 printf("Yes na hulaan mo");
}else
{
  printf("Mali, di mo na hulaan");
}


}