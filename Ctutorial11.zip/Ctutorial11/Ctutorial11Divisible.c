#include<stdio.h>

int main()
{

int number;

printf("Please enter your number\n");
scanf("%i",&number);

if((number % 2) == 0)
{
 printf("Yes it is divisible by 2");
}else
{
 printf("False, it is not");
}


}