#include<stdio.h>

int main()
{

float a,b,c,d,sum,average;

printf("Enter your four numbers\n");
scanf("%f",&a);
scanf("%f",&b);
scanf("%f",&c);
scanf("%f",&d);

sum = a + b + c +d;
average = sum / 4;
printf("The average is %f",average);

}