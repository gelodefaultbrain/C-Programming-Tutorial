#include<stdio.h>

int main()
{

int number;
printf("Enter your number\n");
scanf("%i",&number);

if((number < 10) || (number > 20) && (number == 40))
{
 printf("yes this means the condition is true, so this will be printed out");
}else
{
printf("no this means the condition is false, so this will be printed out");
}

}