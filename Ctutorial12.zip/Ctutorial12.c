#include<stdio.h>

int main()
{

char answer;
printf("What is 1 + 1?\n");
printf("a.0\n");
printf("b.2\n");
printf("c.900\n");

printf("Answer: \n");
scanf("%c",&answer);



switch(answer)
{

 case 'a':
   printf("Wrong answer");
 break;

 case 'b':
   printf("Correct");
 break;

 case 'c':
   printf("Wrong answer c");
 break;

 default:
   printf("Wrong INPUT");
 break;

}



}