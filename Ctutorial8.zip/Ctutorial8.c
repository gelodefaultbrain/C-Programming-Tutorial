#include<stdio.h>

int main()
{

int x = 2; // you can set your x value to any number you want

if(x >= 5)
{
printf("I will be printed kapag ang x ay greater than or equal to 5");
}else if(x <= 10)
{
 printf("I will be printed kapag ang x ay less than or equal to 10");
}else
{
printf("I will be printed out of walang nag True sa mga previous na if else conditions");
}


}